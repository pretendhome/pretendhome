# Getting Started with Palette

**Time to First Success**: 15 minutes  
**What You'll Learn**: How to use Palette's three-tier decision system  
**What You'll Do**: Run your first convergence brief with AI assistance

---

## What is Palette?

Palette is a **three-tier decision system** that makes AI collaboration reliable, bounded, and restartable.

**Not autonomous AI hype.** A toolkit that requires human-AI alignment (convergence) to work.

**What it does**:
- Classifies problems (104 RIUs in taxonomy)
- Routes to specialized agents (8 agent archetypes)
- Learns from success/failure (self-improving system)

---

## What's in This Package

- `tier1/` - Core principles (read first)
- `tier2/` - Agent definitions (read second)  
- `tier3/` - Execution template (read third)
- `taxonomy/` - 104 problem patterns
- `library/` - 88 validated solutions

---

## Installation & Setup (2 Minutes)

### Step 1: Extract the Package
```bash
unzip palette-minimal.zip
cd palette-minimal/
```

### Step 2: Open in Your AI Tool

**Claude Desktop / Claude Code**:
1. Open the `palette-minimal/` folder
2. Start a chat with Claude
3. Say: "Read tier1/TIER1_palette_core.md and help me use Palette"

**Cursor / VS Code + Copilot**:
1. Open `palette-minimal/` as workspace
2. Add tier files to context
3. Reference taxonomy and library as needed

**Any AI Tool**:
- Make sure AI can read the 6 files in this package
- Start by having it read `tier1/TIER1_palette_core.md`

---

## Quick Start: Your First Engagement (10 Minutes)

### Step 1: Tell Your AI to Read the Core Files

**Copy-paste this**:
```
I'm using Palette. Please read these files in order:
1. tier1/TIER1_palette_core.md
2. tier2/TIER2_assumptions.md  
3. tier3/TIER3_decisions_prompt.md

Then help me solve this problem:
[Your problem here]

Start with a convergence brief.
```

**What happens**: Your AI reads the system files, understands Palette, and guides you through convergence.

---

### Step 2: Convergence (Human-AI Alignment)

Before solving your problem, Palette **forces convergence**. Your AI will help you create a **Semantic Blueprint** with these 5 elements:

1. **Goal**: What does success look like?
2. **Roles**: Who does what? (Human vs AI)
3. **Constraints**: What's fixed/required?
4. **Non-Goals**: What's explicitly out of scope?
5. **Success Criteria**: How do we know we're done?

**Why this matters**: Without convergence, AI guesses what you want. With it, you're aligned before execution starts.

---

### Step 3: RIU Selection (Pattern Matching)

After convergence, Palette matches your problem to **RIUs** (Reusable Intervention Units):

**Your AI will**:
1. Read `taxonomy/palette_taxonomy_v1.2.yaml`
2. Match trigger signals from your problem
3. Select appropriate RIUs (patterns)
4. Route to Library entries for solutions

**Example**:
- Problem: "Help me write better documentation"
- Trigger signals: "documentation", "better", "write"
- Matched RIU: RIU-042 (Demo/Narrative Design)
- Routed to: Library entries on structured onboarding

---

### Step 4: Agent Execution

Palette has **8 specialized agents** (from `tier2/TIER2_assumptions.md`):

**Research & Analysis**:
- 🔵 **Argentavis (Argy)**: Research, gather evidence (read-only)

**Design & Build**:
- 🟣 **Tyrannosaurus (Rex)**: Architecture, system design, flags ONE-WAY DOORs
- 🟠 **Therizinosaurus (Theri)**: Implementation, builds from spec

**Debug & Validate**:
- 🔴 **Velociraptor (Raptor)**: Debugging, root cause analysis
- ⚪ **Ankylosaurus (Anky)**: Quality validation, cross-domain patterns

**Communicate & Monitor**:
- 🟢 **Yutyrannus (Yuty)**: Narrative, customer communication, system coherence
- 🟡 **Parasaurolophus (Para)**: Monitoring, anomaly detection

**Coordinate**:
- ⚫ **Orchestrator (Orch)**: Multi-agent workflows (design-only, not implemented)

**Your AI will route to the appropriate agent(s)** based on your problem and RIU selection.

---

### Step 5: Execution & Logging

As your problem is solved, Palette logs everything in `decisions.md` format:

```markdown
## Engagement: [Your Problem]

### Semantic Blueprint
- Goal: [What you want to achieve]
- Constraints: [What's fixed]
- Success Criteria: [How you know you're done]

### RIUs Selected
- RIU-XXX: [Pattern name]
- Routes to: LIB-YYY

### Agent Execution
- Agent: [Which agent]
- Output: [What was produced]
- Success: [Did it work?]

### Artifacts
- [Files created]
- [Deliverables]

### Next Steps
- [What happens next]
```

**This log makes your work restartable.** Anyone can read it and continue.

---

## Key Concepts

### 1. Convergence (Not Autonomous)

**Always start with convergence.** Don't skip this step.

**Bad**: "Just build me a dashboard"  
**Good**: "Let's converge on what 'good dashboard' means first"

**Why**: Without convergence, AI guesses. With it, you're aligned on goals, constraints, and success.

---

### 2. ONE-WAY vs TWO-WAY DOOR Decisions

**TWO-WAY DOOR**: Reversible, cheap to undo
- Example: Refactoring code, changing a prompt, A/B testing
- **AI can proceed autonomously**

**ONE-WAY DOOR**: Hard to reverse, externally binding
- Example: Database selection, architecture commitments, deployments
- **AI must flag 🚨 ONE-WAY DOOR and pause for approval**

**When Rex (Architecture agent) flags a ONE-WAY DOOR, review carefully before approving.**

---

### 3. Agent Boundaries

Each agent has **specific constraints**:

**Argy (Research)**: Can gather evidence, **cannot** make decisions  
**Rex (Architecture)**: Can design systems, **cannot** execute silently  
**Theri (Build)**: Can implement from spec, **cannot** expand scope  
**Raptor (Debug)**: Can fix bugs, **cannot** add features  
**Yuty (Narrative)**: Can create communication, **cannot** overpromise  
**Anky (Validate)**: Can assess quality, **cannot** implement fixes  
**Para (Monitor)**: Can signal anomalies, **cannot** remediate  

**These boundaries prevent "agent creep"** where everyone tries to do everything.

---

### 4. Self-Improvement (Cross-Domain Synthesis)

**After solving complex problems**, optionally run **Step 6** (from `tier3/TIER3_decisions_prompt.md`):

**Yuty asks**: Can I explain this solution clearly?  
**Anky asks**: Is this the best solution we know?  
**Both ask**: Does this reveal patterns applicable elsewhere?

**Result**: 1-3 transferable patterns, system improvements

**Example**: 
- Solved: "Create better onboarding"
- Pattern found: "Structured pathways accelerate understanding"
- Applied to: Convergence briefs (now use 5-section template)

**This is how the system gets smarter over time.**

---

## The Three Tiers Explained

### Tier 1: Core Principles (`tier1/TIER1_palette_core.md`)

**The Physics** - Immutable rules:
- Convergence requirement
- ONE-WAY vs TWO-WAY DOOR classification
- Glass-box architecture (traceable decisions)
- Cross-domain synthesis (system learns)

**Read this file first** to understand the foundation.

---

### Tier 2: Agent Archetypes (`tier2/TIER2_assumptions.md`)

**The Agents** - Specialized roles with constraints:
- 8 agent archetypes
- Each has specific capabilities and limitations
- Maturity model: UNVALIDATED → WORKING → PRODUCTION
- Trust is earned through measured performance

**Read this file second** to understand who does what.

---

### Tier 3: Execution Template (`tier3/TIER3_decisions_prompt.md`)

**The Log** - Decision recording format:
- Semantic Blueprint template
- RIU selection process
- ONE-WAY DOOR flagging
- Agent impression tracking
- Optional Step 6: Cross-domain synthesis

**Read this file third** to understand the execution flow.

---

## The Two Artifacts

### Taxonomy (`taxonomy/palette_taxonomy_v1.2.yaml`)

**104 RIUs** - Problem patterns:
- Relatively static (problems don't change much)
- Trigger signals → Route to solutions
- Maps problems to Library entries

**Think of it as**: The routing table

---

### Library (`library/palette_knowledge_library_v1.2.yaml`)

**88 Validated Q&As** - Solutions with sources:
- Highly dynamic (solutions evolve rapidly)
- Anchored to real documentation
- Maps to RIUs for execution

**Think of it as**: The knowledge base

---

## Common Use Cases

### Use Case 1: Documentation
**Problem**: "Help me write better docs"  
**RIU**: RIU-042 (Demo/Narrative Design)  
**Agent**: Yuty (Narrative)  
**Library**: LIB-088 (Structured onboarding)  
**Time**: 30 minutes

### Use Case 2: Architecture Design
**Problem**: "Design a system for X"  
**RIU**: Architecture RIUs  
**Agent**: Rex (Architecture)  
**Watch for**: 🚨 ONE-WAY DOOR flags  
**Time**: 45 minutes

### Use Case 3: Research
**Problem**: "Find best practices for X"  
**RIU**: Research RIUs  
**Agent**: Argy (Research)  
**Constraint**: Read-only, routes decisions to Rex  
**Time**: 20 minutes

### Use Case 4: Debugging
**Problem**: "Fix this bug"  
**RIU**: Debugging RIUs  
**Agent**: Raptor (Debug)  
**Focus**: Root cause, propose fix (doesn't implement)  
**Time**: 30 minutes

---

## FAQ

### "How is this different from ChatGPT?"

**ChatGPT**: Conversational, no memory, no structure  
**Palette**: Structured convergence, logged decisions, agent boundaries, self-improving

### "Do I need Kiro?"

**No.** Palette works with:
- Claude Desktop / Claude Code
- Cursor / VS Code + Copilot
- Any AI tool that can read text files

### "What if I don't want to use RIUs?"

**You can skip them**, but you lose the benefit of proven patterns. RIUs are resources, not constraints.

### "Is this autonomous AI?"

**No.** Palette **requires** human-AI convergence. It's explicitly not autonomous.

### "How long to learn?"

- **15 minutes**: Understand the concept (this guide)
- **2 hours**: First guided engagement
- **1 day**: Productive use
- **1 week**: Fluent

---

## Next Steps

### 1. Run Your First Engagement

**Copy-paste this to your AI**:
```
I want to solve this problem with Palette:

[Your problem description]

Please:
1. Read tier1/TIER1_palette_core.md
2. Read tier2/TIER2_assumptions.md
3. Help me create a convergence brief (RIU-001)
4. Match to appropriate RIUs from taxonomy
5. Route to Library entries
6. Execute with the right agent(s)
7. Log everything

Let's start with convergence.
```

**Time**: 30-60 minutes  
**Outcome**: Problem solved + understanding of how Palette works

---

### 2. Try Different Problems

**Variety helps learning**:
- Documentation problem (Yuty)
- Architecture problem (Rex)
- Research problem (Argy)
- Debugging problem (Raptor)

**Each shows different agents and patterns.**

---

### 3. Run Step 6 (Cross-Domain Synthesis)

**After a complex engagement**, try:
```
Now run Step 6 (cross-domain synthesis):

1. Yuty validates: Can I explain this clearly?
2. Anky validates: Is this the best solution we know?
3. Both identify: What patterns transfer elsewhere?
4. Recommend: What system improvements to make?
```

**Result**: You'll see how the system improves itself.

---

## Pro Tips

✅ **Always converge first** - Don't skip the Semantic Blueprint  
✅ **Watch for ONE-WAY DOORs** - Review before approving  
✅ **Use agent colors** - Make workflows readable  
✅ **Log decisions** - Enables restartability  
✅ **Run Step 6 on complex problems** - Extract transferable patterns  

---

## You're Ready

**Minimal viable start**:
1. Extract this package
2. Open in your AI tool
3. Say: "Read tier1/TIER1_palette_core.md and help me use Palette"
4. Describe your problem
5. Let AI guide you through convergence

**That's it.** You're using Palette.

---

**Welcome to Palette.** 🎨

**Built by**: Mical Neill (11+ years AWS, Knowledge Engineering)  
**Validated**: 2.5 years, 104 RIUs, 88 Library entries, proven at scale  
**Status**: Production-ready v1.2
