# Palette Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [Unreleased]

### Added
- Repository structure with `/examples/`, `/assets/`, `/.github/`
- `GETTING_STARTED.md` - 5-minute onboarding guide
- `CONTRIBUTING.md` - Contribution guidelines
- Issue templates for agent failures, use cases, library entries
- Pull request template
- Examples directory structure (6 categories)
- Agent directory README
- Visual identity specifications (pending Yuty)

### Changed
- Enhanced documentation structure
- Improved onboarding flow

---

## [1.0.0] - 2026-01-31

### Added
- Initial release of Palette toolkit
- Three-tier system (Tier 1: palette-core.md, Tier 2: assumptions.md, Tier 3: decisions template)
- 7 agent implementations (Argy, Rex, Theri, Raptor, Yuty, Anky, Para)
- Taxonomy v1.2 (104 RIUs)
- Knowledge Library v1.2 (86 questions)
- Interactive onboarding (type "start")
- Demo guide with live agent switching
- Shareable ZIP package (298 KB)

### Status
- All agents at v1.0 UNVALIDATED (0 impressions)
- Ready for first real executions

---

## Version History

- **v1.0.0** (2026-01-31): Initial release
- **v1.2** (Taxonomy/Library): Current artifact versions

---

## Contributors

Thank you to everyone who has contributed to Palette!

### Maintainer
- Mical - Creator and maintainer

### Contributors
(Contributors will be listed here as they submit validated improvements)

---

## How to Contribute

See `CONTRIBUTING.md` for guidelines on submitting:
- Agent failure reports
- Validated use cases
- Library entries
- Taxonomy refinements
- Documentation improvements
