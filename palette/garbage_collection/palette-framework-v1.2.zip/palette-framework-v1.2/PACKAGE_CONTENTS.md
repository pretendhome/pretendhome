# Palette Framework v1.2 - Package Contents

**Version**: 1.2  
**Release Date**: 2026-02-01  
**Status**: Production Ready  
**Compatibility**: Kiro, Claude Code, GitHub Copilot, any AI system

---

## What's Included

### 📖 Documentation (6 files)

1. **GETTING_STARTED.md** (694 lines) - **START HERE**
2. **DEMO.md** (657 lines) - For presentations
3. **README.md** - Overview and quick start
4. **CONTRIBUTING.md** - How to improve the system
5. **CHANGELOG.md** - Version history
6. **LICENSE** - MIT License

### 🏗️ Three-Tier System (3 files)

1. **tier1/TIER1_palette_core.md** - Core Principles
2. **tier2/TIER2_assumptions.md** - Agent Archetypes (8 agents)
3. **tier3/TIER3_decisions_prompt.md** - Execution Template (includes Step 6)

### 🎨 Three Artifacts (3 files)

1. **taxonomy/palette_taxonomy_v1.2.yaml** - 104 RIUs
2. **library/palette_knowledge_library_v1.2.yaml** - 88 Entries (includes LIB-087, LIB-088)
3. **agents/agent_implementation_manual_v1_0b.md** - 8 Archetypes

### 📝 Complete Working Example (8+ files)

**examples/ux-engagement-2026-02-01/** - Real engagement showing cross-domain synthesis

### 🎨 Visual Identity (2 files)

1. **assets/brand-guidelines.md** - Visual specs
2. **assets/README.md** - Asset info

---

## Quick Start (3 Paths)

### Path 1: New User (35 minutes)
1. Extract this ZIP
2. Read **GETTING_STARTED.md**
3. Review **examples/ux-engagement-2026-02-01/**
4. Run your first engagement

### Path 2: Presenter (40 minutes)
1. Extract this ZIP
2. Read **DEMO.md**
3. Practice Part 3 (Live Agent Switching)
4. Present to your audience

### Path 3: Quick Integration (15 minutes)
1. Extract this ZIP
2. Read GETTING_STARTED.md "Installation & Setup"
3. Copy tier files to your project
4. Start using RIUs and Library

---

## Version Info

### v1.2 (Current - 2026-02-01)

**Taxonomy**: v1.2 (104 RIUs) - Enhanced RIU-001
**Library**: v1.2 (88 entries) - Added LIB-087, LIB-088
**Agents**: v1.0b (8 archetypes) - Yuty + Anky roles expanded
**Tiers**: Current - Added Step 6 (cross-domain synthesis)

**Evidence**: All v1.2 changes validated in UX engagement (2026-02-01)

---

**Welcome to Palette.** 🎨

**Start here**: GETTING_STARTED.md
